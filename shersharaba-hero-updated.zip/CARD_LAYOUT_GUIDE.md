# Visual Guide - Writer Card Layout

## Desktop Layout (>1024px) - 3 Cards Per Row

```
┌────────────────────────────────────────────────────────────────────────────┐
│                                                                            │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐      │
│  │   [Avatar 70px] │    │   [Avatar 70px] │    │   [Avatar 70px] │      │
│  │   राज कुमार     │    │   अरुण शर्मा    │    │   राहुल मेहता   │      │
│  │   ⭐ कवि        │    │   ⭐ कहानीकार   │    │   ⭐ लेखक       │      │
│  │   [3 tags]      │    │   [3 tags]      │    │   [3 tags]      │      │
│  │   📍 Location   │    │   📍 Location   │    │   📍 Location   │      │
│  │   "Excerpt..."  │    │   "Excerpt..."  │    │   "Excerpt..."  │      │
│  │   📊 Stats      │    │   📊 Stats      │    │   📊 Stats      │      │
│  │   [Read Button] │    │   [Read Button] │    │   [Read Button] │      │
│  │   min-h: 420px  │    │   min-h: 420px  │    │   min-h: 420px  │      │
│  └─────────────────┘    └─────────────────┘    └─────────────────┘      │
│                                                                            │
└────────────────────────────────────────────────────────────────────────────┘
```

## Tablet Layout (768px - 1024px) - 2 Cards Per Row

```
┌──────────────────────────────────────────────────────┐
│                                                      │
│  ┌────────────────────┐    ┌────────────────────┐  │
│  │   [Avatar 70px]    │    │   [Avatar 70px]    │  │
│  │   राज कुमार        │    │   अरुण शर्मा       │  │
│  │   ⭐ कवि           │    │   ⭐ कहानीकार      │  │
│  │   [Tags]           │    │   [Tags]           │  │
│  │   📍 Location      │    │   📍 Location      │  │
│  │   "Excerpt..."     │    │   "Excerpt..."     │  │
│  │   📊 Stats         │    │   📊 Stats         │  │
│  │   [Read Button]    │    │   [Read Button]    │  │
│  │   min-h: 400px     │    │   min-h: 400px     │  │
│  └────────────────────┘    └────────────────────┘  │
│                                                      │
└──────────────────────────────────────────────────────┘
```

## Mobile Layout (≤480px) - 1 Card Per Row

```
┌─────────────────────────────┐
│                             │
│  ┌───────────────────────┐  │
│  │   [Avatar 70px]       │  │
│  │   राज कुमार           │  │
│  │   ⭐ कवि              │  │
│  │   [रोमांस][प्रेम]     │  │
│  │   📍 फरीदाबाद        │  │
│  │   "जब दिल से..."     │  │
│  │   📊 45 📗 1250       │  │
│  │   [पढ़ें →]          │  │
│  │   min-h: 380px        │  │
│  └───────────────────────┘  │
│                             │
│  ┌───────────────────────┐  │
│  │   [Avatar 70px]       │  │
│  │   अरुण शर्मा          │  │
│  │   ⭐ कहानीकार         │  │
│  │   [Tags]              │  │
│  │   📍 Location         │  │
│  │   "Excerpt..."        │  │
│  │   📊 Stats            │  │
│  │   [पढ़ें →]          │  │
│  │   min-h: 380px        │  │
│  └───────────────────────┘  │
│                             │
└─────────────────────────────┘
```

---

## Card Content Structure (Vertical Layout)

```
┌─────────────────────────────┐
│                             │
│         [Avatar]            │ ← 70x70px, border-radius: 50%
│        margin: 12px         │
│                             │
├─────────────────────────────┤
│       राज कुमार             │ ← 16px font, 8px margin
│                             │
├─────────────────────────────┤
│      ⭐ कवि                 │ ← 11px badge, 8px margin
│                             │
├─────────────────────────────┤
│  [रोमांस] [प्रेम] [उदासी]  │ ← 10px tags, wrap, 8px margin
│                             │
├─────────────────────────────┤
│  📍 फरीदाबाद, हरियाणा      │ ← 11px location, 8px margin
│                             │
├─────────────────────────────┤
│  "जब दिल से निकले एक आहट,  │ ← 12px excerpt, italic
│   और होंठों पर आए..."      │    2 lines max, 8px margin
│                             │
├─────────────────────────────┤
│  📚 45  ❤️ 1250  👁️ 8500   │ ← 11px stats, 12px margin
│                             │
├─────────────────────────────┤
│                             │
│    (flexible space)         │ ← flex-grow area
│                             │
├─────────────────────────────┤
│      [पढ़ें →]              │ ← 12px button at bottom
│                             │    margin-top: auto
└─────────────────────────────┘
      Total: min 420px
```

---

## Size Comparisons

### Before vs After Element Sizes:

| Element | Before | After | Reduction |
|---------|--------|-------|-----------|
| Avatar | 90x90px | 70x70px | -22% |
| Name | 18px | 16px | -2px |
| Badge | 12px | 11px | -1px |
| Tags | 11px | 10px | -1px |
| Location | 12px | 11px | -1px |
| Excerpt | 13px | 12px | -1px |
| Stats | 12px | 11px | -1px |
| Button | 13px | 12px | -1px |
| Card Padding | 20px | 15px (h) | -25% |

### Spacing Improvements:

| Spacing | Before | After | Reduction |
|---------|--------|-------|-----------|
| Avatar margin-bottom | 15px | 12px | -3px |
| Badge margin-bottom | 10px | 8px | -2px |
| Tags margin | 10px | 8px | -2px |
| Tag padding | 5px 12px | 4px 10px | -1px -2px |
| Location margin-bottom | 12px | 8px | -4px |
| Excerpt margin | 10px | 8px | -2px |
| Stats margin-bottom | 15px | 12px | -3px |
| Stats gap | 15px | 12px | -3px |

---

## Card Height Strategy

```
Desktop:    min-height: 420px  ┐
                               │ Flexible height
Tablet:     min-height: 400px  │ based on content
                               │
Mobile:     min-height: 380px  ┘

Note: Cards will grow taller if content requires,
but will never be shorter than the minimum.
```

---

## Responsive Breakpoints

```
┌────────────────────────────────────────────────────┐
│                                                    │
│  1920px ─────► 3 cards ─────► 420px min-height   │
│  1440px ─────► 3 cards ─────► 420px min-height   │
│  1280px ─────► 3 cards ─────► 420px min-height   │
│  1024px ─────► 3 cards ─────► 420px min-height   │
│                                                    │
│  ─────────────── BREAKPOINT @ 1024px ─────────── │
│                                                    │
│   768px ─────► 2 cards ─────► 400px min-height   │
│   480px ─────► 2 cards ─────► 400px min-height   │
│                                                    │
│  ─────────────── BREAKPOINT @ 480px ──────────── │
│                                                    │
│   375px ─────► 1 card  ─────► 380px min-height   │
│   360px ─────► 1 card  ─────► 380px min-height   │
│                                                    │
└────────────────────────────────────────────────────┘
```

---

## Content Overflow Prevention

### Techniques Used:

1. **Excerpt Clamping**
   ```css
   display: -webkit-box;
   -webkit-line-clamp: 2;
   -webkit-box-orient: vertical;
   overflow: hidden;
   max-height: 36px;  /* 12px × 1.5 line-height × 2 lines */
   ```

2. **Tag Wrapping**
   ```css
   flex-wrap: wrap;
   gap: 6px;
   ```

3. **Stats Wrapping**
   ```css
   flex-wrap: wrap;
   gap: 12px;
   ```

4. **Flexible Container**
   ```css
   display: flex;
   flex-direction: column;
   min-height: 420px;  /* Not fixed height */
   ```

5. **Button at Bottom**
   ```css
   margin-top: auto;  /* Pushes to bottom */
   ```

---

## Grid Display Logic

```javascript
// Desktop (>1024px)
grid-template-columns: repeat(3, 1fr);

// Tablet (768-1024px)
@media (max-width: 1024px) {
    grid-template-columns: repeat(2, 1fr);
}

// Mobile (≤480px)
@media (max-width: 480px) {
    grid-template-columns: 1fr;
}
```

---

## Pages Using This Layout

✅ **index.html** - Home page
   - Top Writers section
   - 3 cards per row on desktop

✅ **all-writers.html** - Lekhak page
   - All 4 tabs (सभी लेखक, कवि, कहानीकार, अन्य)
   - 3 cards per row on desktop
   - Filter results display

---

**Perfect card layout for all screen sizes! 🎯**
